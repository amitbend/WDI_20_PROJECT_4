### August 20, 2015

- Pulled latest from Google and Material Design Icons
- Updated Community based set in 'iconset' folder
